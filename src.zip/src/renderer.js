// Global variable cache
var scene = getById('scene');
var fileInput = getById('fileInput');
var colorInput = getById('colorInput');
var zoomInput = getById('zoom');
var speedInput = getById('speed');
var mixInput = getById('default-mix');
var skinList = getById('skins');
var animationList = getById('animations');
var slotList = getById('slots');
var alphaMode = 1;
var slotIndex = 0;
var availableAnimations = [];
var slots = [];
var isExporting = false;
var track = {current: 0};
var superposition = false;
var currentSpeed = 1;

// --- PixiJS v8 Initialization ---
var app = new PIXI.Application();

var viewCanvas = document.createElement('canvas');
scene.appendChild(viewCanvas);

// Bind references for your other scripts
app.view = viewCanvas;
app.canvas = viewCanvas;

(async () => {
    await app.init({
        canvas: viewCanvas,
        resizeTo: scene,
        antialias: true,
        autoDensity: true,
        backgroundAlpha: 0,
        preserveDrawingBuffer: true,
        resolution: window.devicePixelRatio || 1
    });
})();

var reload = async () => {
    if (typeof resetZoom === 'function') resetZoom();
    if (typeof resetSpeed === 'function') resetSpeed();

    app.stage.removeChildren();
    PIXI.Assets.reset();

    skinList.innerHTML = '';
    slotList.innerHTML = '';
    animationList.innerHTML = '';

    const track0 = getById('animation-track0');
    if (track0) track0.click();
};

var loadFiles = async (urls) => {
    try {
        await reload();

        const jsonUrls = urls.filter(u => u.endsWith('.json') || u.endsWith('.skel'));
        const atlasUrls = urls.filter(u => u.endsWith('.atlas'));
        const imgUrls = urls.filter(u => /\.(png|jpg|jpeg|webp)$/i.test(u));

        if (jsonUrls.length === 0 || atlasUrls.length === 0) {
            alert("Please drop at least one .json/.skel and one .atlas file together.");
            return;
        }

        // 1. THE NATIVE ALIAS TRICK (No hacky interceptors!)
        // We tell Pixi's native loader to map any missing .webp requests directly to your .jpg
        imgUrls.forEach(imgUrl => {
            const baseUrl = imgUrl.substring(0, imgUrl.lastIndexOf('.'));
            PIXI.Assets.add({ alias: baseUrl + '.webp', src: imgUrl });
            PIXI.Assets.add({ alias: baseUrl + '.png', src: imgUrl });
            PIXI.Assets.add({ alias: baseUrl + '.jpg', src: imgUrl });
        });

        // 2. LOAD SPINE NATIVELY
        const loadedSkeletonsData = [];
        for (let i = 0; i < jsonUrls.length; i++) {
            const jsonUrl = jsonUrls[i];
            const baseJsonName = jsonUrl.substring(0, jsonUrl.lastIndexOf('.'));

            // Find matching atlas, or fallback to the first one available
            let matchedAtlas = atlasUrls.find(a => a.startsWith(baseJsonName)) || atlasUrls[0];

            if (matchedAtlas) {
                const spineId = 'spine_' + i + '_' + Date.now();

                // Explicitly link the JSON to the Atlas using official v8 syntax
                PIXI.Assets.add({
                    alias: spineId,
                    src: jsonUrl,
                    data: { spineAtlasFile: matchedAtlas }
                });

                // Load it. Pixi will automatically fetch the aliased JPG behind the scenes.
                const skeletonData = await PIXI.Assets.load(spineId);

                // Ensure it actually parsed successfully into a SkeletonData object
                if (skeletonData && skeletonData.bones) {
                    loadedSkeletonsData.push(skeletonData);
                }
            }
        }

        onLoaded(loadedSkeletonsData);

    } catch (e) {
        console.error("v8 Asset Load Failed:", e);
        alert("Failed to load assets. See console.");
    }
};

function onLoaded(skeletonDataArray) {
    if (!skeletonDataArray || skeletonDataArray.length === 0) return;

    if (!superposition) {
        slotIndex = 0;
        skinList.innerHTML = '';
        slotList.innerHTML = '';
        animationList.innerHTML = '';
        availableAnimations = [];
    }

    let skins = [];
    const speed = +speedInput.value;
    const scale = +zoomInput.value / 100;
    const defaultMix = +mixInput.value;

    skeletonDataArray.forEach(spineData => {
        try {
            // Instantiate the Official v8 Spine object
            const skeleton = new spine.Spine(spineData);

            skeleton.position.set(app.canvas.width / 2, app.canvas.height / 2);
            skeleton.scale.set(scale);
            skeleton.state.timeScale = speed;
            if (skeleton.state.data) skeleton.state.data.defaultMix = defaultMix;
            skeleton.autoUpdate = true;

            // Extract UI data
            const skeletonSkins = skeleton.skeleton.data.skins.map(s => s.name);
            const skeletonAnims = skeleton.skeleton.data.animations.map(a => {
                return { name: a.name, duration: a.duration.toFixed(3) };
            });

            skins = skins.concat(skeletonSkins.filter(s => !skins.includes(s)));
            availableAnimations = availableAnimations.concat(skeletonAnims);
            app.stage.addChild(skeleton);
            decorate(skeleton);

            // Populate Slots list
            for (const slot of skeleton.skeleton.slots) {
                const li = createTag('li');
                const title = createTag('span');
                const div = createTag('div');
                const label = createTag('label');
                const input = createTag('input');
                const value = createTag('span');

                title.classList.add('slot-title');
                div.classList.add('slot-alpha');
                value.classList.add('slot-alpha-value');
                label.setAttribute('for', `${slotIndex}-${slot.data.name}`);
                input.setAttribute('id', `${slotIndex++}-${slot.data.name}`);
                input.setAttribute('type', 'range');
                input.setAttribute('name', 'slot');
                input.setAttribute('value', (slot.color.a * 100).toFixed());
                input.setAttribute('min', '0');
                input.setAttribute('max', '100');
                input.setAttribute('step', '1');

                title.innerText = slot.data.name;
                label.innerText = 'Α:';
                value.innerText = slot.color.a.toFixed(2);

                div.append(label);
                div.append(input);
                div.append(value);
                li.append(title);
                li.append(div);

                input.addEventListener('input', () => {
                    const alpha = +input.value / 100;
                    slot.color.a = alpha;
                    value.innerText = alpha.toFixed(2);
                });
                slotList.append(li);
            }
        } catch (e) {
            console.error('Spine 4.2 Skeleton creation failed:', e);
        }
    });

    let existedSkins = Array.from(skinList.children).map(li => li.children[0].value);
    skins.forEach(s => {
        if (existedSkins.includes(s)) return;
        const li = createTag('li');
        li.innerHTML = `<label><input type="radio" name="skin" value="${s}" class="list-option"> ${s}</label>`;
        li.querySelector('input').addEventListener('change', (ev) => {
            if (typeof setSkin === 'function') setSkin(ev.target.value);
        });
        if (skinList.innerHTML === '') li.querySelector('input').checked = true;
        skinList.append(li);
    });

    availableAnimations.forEach(a => {
        const li = createTag('li');
        li.innerHTML = `<label><input type="checkbox" name="animation" value="${a.name}" class="list-option"> ${a.name} <span>${a.duration}s</span></label>`;
        li.querySelector('input').addEventListener('click', toggleAnimation);
        animationList.append(li);
    });
}

function decorate(skeleton) {
    let isDragging = false;
    let mouseX, mouseY, deltaX, deltaY;

    app.canvas.addEventListener('pointerdown', (event) => {
        if (event.button === 0) {
            isDragging = true;
            mouseX = event.clientX;
            mouseY = event.clientY;
        }
    });
    app.canvas.addEventListener('pointermove', (event) => {
        if (isDragging) {
            deltaX = event.clientX - mouseX;
            deltaY = event.clientY - mouseY;
            skeleton.x += deltaX;
            skeleton.y += deltaY;
            mouseX = event.clientX;
            mouseY = event.clientY;
        }
    });
    window.addEventListener('pointerup', () => isDragging = false);

    app.canvas.addEventListener('wheel', (event) => {
        event.preventDefault();
        const originalScale = skeleton.scale.x;
        const scaleFactor = event.deltaY > 0 ? 0.95 : 1.05;
        const minScale = 0.1, maxScale = 5;
        const newScale = Math.min(Math.max(originalScale * scaleFactor, minScale), maxScale);

        skeleton.scale.set(newScale);
        zoomInput.value = Math.round(newScale * 100);
        const zoomShow = getById('zoom-show');
        if (zoomShow) zoomShow.innerText = zoomInput.value + '%';

        skeleton.x -= (event.offsetX - skeleton.x) * (skeleton.scale.x / originalScale - 1);
        skeleton.y -= (event.offsetY - skeleton.y) * (skeleton.scale.y / originalScale - 1);
    });
    return skeleton;
}

function toggleAnimation(ev) {
    const animations = document.querySelectorAll('input[name="animation"]');
    if (ev.target.checked) {
        track[track.current] = ev.target.value;
        animations.forEach(rb => {
            if (rb !== ev.target) rb.checked = false;
        });
        if (typeof playAnimation === 'function') playAnimation(track.current, ev.target.value, true);
    } else {
        track[track.current] = null;
        if (typeof clearAnimation === 'function') clearAnimation(track.current);
    }
}

function openExportWindow() {
    isExporting = true;
    if (typeof preload !== 'undefined') preload.openExportWindow(availableAnimations);
}

async function exportAnimation(options) {
    const {format, framerate, animation, output, duration} = options;
    const speed = +speedInput.value;
    const delta = 1 / framerate;
    const frameNumber = Math.floor(duration / speed / delta);

    let frameIndex = 0;
    if (typeof preload !== 'undefined') preload.sendExportProgress({step: 0, frameNumber});

    app.stage.children.forEach(a => a.autoUpdate = false);

    if (typeof preload !== 'undefined') {
        preload.prepareExport(animation).then(() => {
            for (let i = 1; i < 7; i++) {
                if (track[i] && typeof playAnimation === 'function') playAnimation(i, track[i], true);
            }
            if (typeof playAnimation === 'function') playAnimation(0, animation, false);
            app.stage.children.forEach(a => a.update(0));
            setTimeout(animate, 100);
        });
    }

    async function animate() {
        if (frameIndex >= frameNumber) {
            if (typeof preload !== 'undefined') {
                preload.sendExportProgress({step: 2});
                preload.executeExport({format, framerate, animation, output});
            }
            return;
        }

        let data = app.canvas.toDataURL('image/png');
        if (typeof preload !== 'undefined') {
            preload.saveImage({
                index: String(frameIndex++).padStart(5, '0'),
                data
            }).then(() => {
                preload.sendExportProgress({step: 1, frameIndex});
                app.stage.children.forEach(a => a.update(delta));
                animate();
            });
        }
    }
}